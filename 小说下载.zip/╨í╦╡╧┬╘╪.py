# coding=utf-8
import requests
from bs4 import BeautifulSoup
if __name__ == '__main__':
    headers={
        'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36 Edg/90.0.818.56'
    }
    url='https://www.biquge5200.cc/0_195/'
    response=requests.get(url=url,headers=headers)
    response.encoding='gbk'
    page_text=response.text
    soup=BeautifulSoup(page_text,'lxml')
    dd=soup.select('.box_con dd>a')
    fp=open('./超品相师.txt','w',encoding='utf-8')
    for title in dd:
        fp.write(title.text+'\n')
        new_url=title['href']
        fp.write(new_url+'\n')
        new_page_text=requests.get(url=new_url,headers=headers).text
        soup1=BeautifulSoup(new_page_text,'lxml')
        content=soup1.select('#content p')
        for con in content:
            fp.write(con.text+'\n')
        print("一章完成")


