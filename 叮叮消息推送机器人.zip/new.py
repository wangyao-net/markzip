import time
import hmac
import hashlib
import base64
import json
import urllib.parse
import urllib.request
import requests
import json
import datetime
from bs4 import BeautifulSoup
import sccm
txt=[]
today=datetime.date.today()
yesterday=str(today - datetime.timedelta(days=1))+' 00:00:00'
class DingDingWebHook(object):
    def __init__(self, secret=None, url=None):
        """
        :param secret: 安全设置的加签秘钥
        :param url: 机器人没有加签的WebHook_url
        """
        if secret is not None:
            secret = secret
        else:
            secret = 'SEC4db346c2a72bdfdd5702a424658a48c1e55a5c2fbbdb3244d1d93462507c4522'  # 加签秘钥
        if url is not None:
            url = url
        else:
            url = "https://oapi.dingtalk.com/robot/send?access_token=651dec1415c7286caf23202f111824273ff53657e7012e1866b3aa9d59f7dbcc"  # 无加密的url

        timestamp = round(time.time() * 1000)  # 时间戳
        secret_enc = secret.encode('utf-8')
        string_to_sign = '{}\n{}'.format(timestamp, secret)
        string_to_sign_enc = string_to_sign.encode('utf-8')
        hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()
        sign = urllib.parse.quote_plus(base64.b64encode(hmac_code))  # 最终签名

        self.webhook_url = url + '&timestamp={}&sign={}'.format(timestamp, sign)  # 最终url，url+时间戳+签名
    def send_meassage(self, data):
        """
        发送消息至机器人对应的群
        :param data: 发送的内容
        :return:
        """
        header = {
            "Content-Type": "application/json",
            "Charset": "UTF-8"
        }
        send_data = json.dumps(data)  # 将字典类型数据转化为json格式
        send_data = send_data.encode("utf-8")  # 编码为UTF-8格式
        request = urllib.request.Request(url=self.webhook_url, data=send_data, headers=header)  # 发送请求

        opener = urllib.request.urlopen(request)  # 将请求发回的数据构建成为文件格式
        print(opener.read())  # 打印返回的结果

if __name__ == '__main__':
    for i in range(len(sccm.new_titele)):
        my_secret = 'SEC4db346c2a72bdfdd5702a424658a48c1e55a5c2fbbdb3244d1d93462507c4522'
        my_url = 'https://oapi.dingtalk.com/robot/send?access_token=651dec1415c7286caf23202f111824273ff53657e7012e1866b3aa9d59f7dbcc'
        my_data = {
            "msgtype": "actionCard",
            "actionCard": {
                "title": sccm.new_titele[i],
                "text": "![screenshot](https://image.3001.net/images/20210425/1619345260_60853f6cf326b287726ce.png!small)",
                "singleTitle": sccm.new_titele[i],
                "singleURL": sccm.new_url[i]
            }
        }
        flase=0
        for m in txt:
            if sccm.new_titele[i]==m:
                flase=1
        if flase == 0:
            dingding = DingDingWebHook(secret=my_secret, url=my_url)
            dingding.send_meassage(my_data)
        txt.append(sccm.new_titele[i])
        time.sleep(60)