import time
import hmac
import hashlib
import base64
import json
import urllib.parse
import urllib.request
import requests
import json
import datetime
from bs4 import BeautifulSoup
today=datetime.date.today()
yesterday=str(today - datetime.timedelta(days=1))+' 00:00:00'
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36'
}
url1='http://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt/'
response=requests.get(url=url1,headers=headers)
response.encoding='uft-8'
page_text=response.text
title1_list = []
pic_list = []
url1_list = []
time0_list = []
time1_list = []
new_titele = []
new_url = []
m=[]
soup=BeautifulSoup(page_text,'lxml')
li_list=soup.select('#list > li')
for li in li_list:
    title1_list.append(li.a.string)
    url1_list.append("http://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt/"+li.a['href'])
    time0_list.append(li.span.string)
for i in time0_list:
    time1_list.append(str(i))
for i in time1_list:
    if i > yesterday:
        m.append(i)
for i in range(len(m)):
    new_titele.append(title1_list[i])
    new_url.append(url1_list[i])


# url2 = 'https://news.eol.cn/'
# response = requests.get(url=url2, headers=headers)
# response.encoding='utf-8'
# page_text=response.text
# soup = BeautifulSoup(page_text, 'lxml')
# title2_list = []
# url2_list = []
# time2_list = []
# time2 = []
# for i in range(6):
#     title2_list.append(soup.select('.biaoti > div > a')[i].text)
#     url2_list.append(soup.select('.biaoti > div > a')[i]['href'])
#     time2_list.append(soup.select('.time')[i].text)
# for i in time2_list:
#     time2.append(str(i))
# for i in time2:
#     if i > yesterday:
#         m = time2.count(i)
#         new_titele.append(title2_list[m])
#         new_url.append(url2_list[m])



# url3 = 'https://www.t00ls.net/Penetration-articles.html'
# page_text = requests.get(url=url3, headers=headers).text
# soup = BeautifulSoup(page_text, 'lxml')
# title3_list = []
# url3_list = []
# time3_list = []
# time3 = []
# for i in range(10):
#     title3_list.append(soup.select('.item_content > h4 > a')[i].text)
#     url3_list.append(soup.select('.item_content > h4 > a')[i]['href'])
#     time3_list.append(soup.select('.meta_date')[i].text)
# for i in time3_list:
#     time3.append(str(i))
# for i in time3:
#     if i > yesterday:
#         m = (time3.index(i))
#         new_titele.append(title3_list[m])
#         new_url.append('https://www.t00ls.net/' + url3_list[m])






#网络安全

# url1 = 'https://www.freebuf.com/fapi/frontend/category/list?'
# paras = {
#     'name': 'network',
#     'page': '1',
#     'limit': '20',
#     'select': ' 0',
#     'order': '0',
#     'type': 'category'
# }
# title1_list = []
# pic_list = []
# url1_list = []
# time0_list = []
# time1_list = []
# new_titele = []
# new_url = []
# dic_obj = requests.get(url=url1, params=paras, headers=headers).json()
# dictions = dic_obj.get('data')
# for tit in dictions['data_list']:
#     title1_list.append(tit['post_title'])
# for pic in dictions['data_list']:
#     pic_list.append(pic['column_post_picture'])
# for url in dictions['data_list']:
#     url1_list.append('https://www.freebuf.com/' + url['url'])
# for time in dictions['data_list']:
#     time0_list.append(time['post_date'])
# for i in time0_list:
#     time1_list.append(str(i))
# for i in time1_list:
#     if i > yesterday:
#         m = (time1_list.index(i))
#         new_titele.append(title1_list[m])
#         new_url.append(url1_list[m])
# url2 = 'https://www.secpulse.com/archives/category/articles/web'
# page_text = requests.get(url=url2, headers=headers).text
# soup = BeautifulSoup(page_text, 'lxml')
# title2_list = []
# url2_list = []
# time2_list = []
# time2 = []
# for i in range(6):
#     title2_list.append(soup.select('.bot > a')[i].text)
#     url2_list.append(soup.select('.bot > a')[i]['href'])
# for urls in url2_list:
#     page_for = requests.get(url=urls, headers=headers).text
#     soup1 = BeautifulSoup(page_for, 'lxml')
#     time2_list.append(soup1.find('span', class_='time mr20').text)
# for i in time2_list:
#     time2.append(str(i))
# for i in time2:
#     if i > yesterday:
#         m = time2.count(i)
# for i in range(m):
#     new_titele.append(title2_list[i])
#     new_url.append(url2_list[i])
# url3 = 'https://www.t00ls.net/Penetration-articles.html'
# page_text = requests.get(url=url3, headers=headers).text
# soup = BeautifulSoup(page_text, 'lxml')
# title3_list = []
# url3_list = []
# time3_list = []
# time3 = []
# for i in range(10):
#     title3_list.append(soup.select('.item_content > h4 > a')[i].text)
#     url3_list.append(soup.select('.item_content > h4 > a')[i]['href'])
#     time3_list.append(soup.select('.meta_date')[i].text)
# for i in time3_list:
#     time3.append(str(i))
# for i in time3:
#     if i > yesterday:
#         m = (time3.index(i))
#         new_titele.append(title3_list[m])
#         new_url.append('https://www.t00ls.net/' + url3_list[m])
