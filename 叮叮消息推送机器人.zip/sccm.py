import time
import hmac
import hashlib
import base64
import json
import urllib.parse
import urllib.request
import requests
import json
import re
import datetime
from bs4 import BeautifulSoup
today=datetime.date.today()
yesterday=str(today - datetime.timedelta(days=1))+' 00:00:00'
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36'
}
url1='http://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt/'
response=requests.get(url=url1,headers=headers)
response.encoding='uft-8'
page_text=response.text
title1_list = []
pic_list = []
url1_list = []
url1_list1=[]
time1_list = []
new_titele = []
new_url = []
m=[]
str1=''
soup=BeautifulSoup(page_text,'lxml')
li_list=soup.select('#list > li')
for li in li_list:
    title1_list.append(li.a.string)
    url1_list1.append(li.a['href'])
    time1_list.append(str(li.span.string))
for i in url1_list1:
    string = list(i)
    string[0] = ''
    url1_list.append('http://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt'+str1.join(string))
for i in time1_list:
    if i > yesterday:
        m.append(i)
for i in range(len(m)):
    new_titele.append(title1_list[i])
    new_url.append(url1_list[i])
url2 = 'https://news.eol.cn/'
response = requests.get(url=url2, headers=headers)
response.encoding='utf-8'
page_text=response.text
soup = BeautifulSoup(page_text, 'lxml')
title2_list = []
url2_list2=[]
url2_list = []
time2_list = []
time2 = []
n=[]
for i in range(6):
    title2_list.append(soup.select('.biaoti > div > a')[i].text)
    url2_list2.append(soup.select('.biaoti > div > a')[i]['href'])
    time2_list.append(str(soup.select('.time')[i].text))
    for i in url2_list2:
        string=list(i)
        string[0]=''
        url2_list.append('https://news.eol.cn/'+str1.join(string))
for i in time2_list:
    if i > yesterday:
        n.append(i)
for i in range(len(n)):
    new_titele.append(title2_list[i])
    new_url.append(url2_list[i])

url3='http://www.jyb.cn/rmtsy1240/zhxw/'
response=requests.get(url=url3,headers=headers)
response.encoding='uft-8'
page_text=response.text
with open('./naem.html','w',encoding='utf-8')as fp:
    fp.write(page_text)
title3_list=[]
url3_list=[]
time3_list=[]
a=[]
ex='<span>发布时间：(.*?)</span>'
time3_list1=(re.findall(ex,page_text,re.S))
soup=BeautifulSoup(page_text,'lxml')
li_list=soup.select('.yxj_left > ul > li')
for li in li_list:
    title3_list.append(li.a['title'])
    url3_list.append(li.a['href'])
for time in time3_list1:
    time3_list.append(str(time))
for times in time3_list:
    if times>yesterday:
        a.append(times)
for i in range(len(a)):
    new_titele.append(title3_list[i])
    new_url.append(url3_list[i])