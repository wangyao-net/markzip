#coding='utf-8'
import time
import re
import requests
import datetime
from bs4 import BeautifulSoup
today=datetime.date.today()
yesterday=str(today - datetime.timedelta(days=1))+' 00:00:00'
headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Safari/537.36'
}
new_titele = []
new_url = []
# url1='http://www.moe.gov.cn/jyb_xwfb/gzdt_gzdt/'
# response=requests.get(url=url1,headers=headers)
# response.encoding='uft-8'
# page_text=response.text
# title1_list = []
# pic_list = []
# url1_list = []
# time0_list = []
# time1_list = []
# soup=BeautifulSoup(page_text,'lxml')
# li_list=soup.select('#list > li')
# for li in li_list:
#     title1_list.append(li.a.string)
#     url1_list.append("http://www.moe.gov.cn/jyb_xwfb/"+li.a['href'])
#     time0_list.append(li.span.string)
# for i in time0_list:
#     time1_list.append(str(i))
#
# for i in time1_list:
#     if i > yesterday:
#         m=(time1_list.index(i))
#         new_titele.append(title1_list[m])
#         new_url.append(url1_list[m])




# url2 = 'https://news.eol.cn/'
# response = requests.get(url=url2, headers=headers)
# response.encoding='utf-8'
# page_text=response.text
# soup = BeautifulSoup(page_text, 'lxml')
# title2_list = []
# url2_list = []
# time2_list = []
# time2 = []
# for i in range(6):
#     title2_list.append(soup.select('.biaoti > div > a')[i].text)
#     url2_list.append(soup.select('.biaoti > div > a')[i]['href'])
#     time2_list.append(soup.select('.time')[i].text)
# # for urls in url2_list:
# #     page_for = requests.get(url=urls, headers=headers).text
# #     soup1 = BeautifulSoup(page_for, 'lxml')
# #     time2_list.append(soup1.find('span', class_='time mr20').text)
# for i in time2_list:
#     time2.append(str(i))
# for i in time2:
#     if i > yesterday:
#         m = time2.count(i)
#         new_titele.append(title2_list[m])
#         new_url.append(url2_list[m])


url3 = 'http://www.jyb.cn/search.html?&&search154'
response = requests.get(url=url3, headers=headers)
response.encoding='utf-8'
page_text=response.text
soup = BeautifulSoup(page_text, 'lxml')
# ex='<span>发布时间：(/d/d/d/d-/d/d-/d/d)</span>'
title3_list = []
url3_list = []
url_next=[]
time3_list = []
time3 = []
for i in range(3):
    title3_list.append(soup.select('.yxj_list a')[i].text)
    url3_list.append(soup.select('.yxj_list a')[i]['href'])
for url in url3_list:
    page1_text=requests.get(url=url,headers=headers).text

    # time_index=re.findall(ex,page1_text,re.S)
    # time3_list.append(time_index)
    soup1=BeautifulSoup(page1_text,'lxml')
    title3_list.append(soup1.select('.xl_title > h2 > span').text)
    # time3_list.append(soup1.select('.yxj_left > div > h2> span').text)
for i in time3_list:
    time3.append(str(i))
for i in time3:
    if i > yesterday:
        m = (time3.index(i))
        new_titele.append(title3_list[m])
        new_url.append(url3_list[m])
print(new_titele)
print(new_url)


# <ul class="yxj_list"> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_552085.html" target="_blank">新疆全面加强大中小学劳动教育</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（记者&nbsp;蒋夫尔）日前，新疆维吾尔自治区党委和政府印发了《自治区关于全面加强新时代大中小学劳动教育的实施意见》，明确了新时代全区大中小学劳动教育的目标、内容、重点任务和保障措施，推动全...</h2>  <h3> 作者：蒋夫尔&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_552052.html" target="_blank">革命先驱李大钊先生一封书信面世，内容事关家乡教育</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（记者&nbsp;周洪松）日前，一封弥足珍贵的信函在河北师范大学职工宿舍面世。这封信，是中国共产党的主要创始人李大钊先生当年与好友宁绍先的交往信函。信中内容涉及李大钊先生对家乡河北省乐亭县教育...</h2>  <h3> 作者：周洪松&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_551841.html" target="_blank">国务院成立未成年人保护工作领导小组</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（记者&nbsp;欧媚）近日，国务院办公厅印发通知，成立国务院未成年人保护工作领导小组，国务院副总理孙春兰任领导小组组长。领导小组办公室设在民政部，承担领导小组日常工作。通知显示，为贯彻落实《...</h2>  <h3> 作者：欧媚&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_551838.html" target="_blank">高校书院如何提升育人功能？</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（记者&nbsp;任朝霞）高校书院如何提升育人功能？书院导师如何更好地助力学生成长成才？4月23日，来自复旦大学、华东师范大学、上海大学、苏州大学、江苏师范大学、苏州科技大学、南京审计大学、温...</h2>  <h3> 作者：任朝霞&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_551643.html" target="_blank">湖南工程学院：大学生唱百首红歌献给党</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（通讯员&nbsp;杨欢&nbsp;涂璐&nbsp;记者&nbsp;阳锡叶）“我们迎着初升的太阳，走在崭新的道路上，我们是优秀的中华儿女，谱写时代的新篇章……”近期，湖南工程学院青年学生以团支...</h2>  <h3> 作者：阳锡叶 杨欢 涂璐&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_551846.html" target="_blank">教育部启动2021年国家级大学生创新创业训练计划立项项目报送工作</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（记者&nbsp;高众）为进一步深化新发展阶段高校创新创业教育改革，引导大学生面向国家重大战略需求开展创新创业活动，强化重点领域创新创业成果的培育与产出，教育部于近日印发通知，启动2021年国...</h2>  <h3> 作者：高众&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_551845.html" target="_blank">华北电力大学启动“学党史、进社区”携手行动</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（记者&nbsp;单艺伟）“学校和社区、社会组织等基层党组织紧密配合，围绕超大城市社区治理的迫切需求，不断探索党史学习教育的新方式、新方法，打造活动特色，形成工作亮点。”4月27日，在华北电力...</h2>  <h3> 作者：单艺伟&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzcg/xwy/wzxw/202104/t20210428_551978.html" target="_blank">青岛举办微党课大赛</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国教育报-中国教育新闻网讯（记者&nbsp;孙军）4月27日，青岛市委教育工委、市教育局在青岛艺术学校举行“‘百人、百堂、百部’话百年风华”微党课大赛决赛。本次比赛在青岛艺术学校设主会场，各学校设分会场，通过青岛市广播...</h2>  <h3> 作者：孙军&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzgjyb/202104/t20210428_551188.html" target="_blank">解放思想深化改革凝心聚力担当实干&nbsp;建设新时代中国特色社会主义壮美广西</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;新华社南宁4月27日电&nbsp;中共中央总书记、国家主席、中央军委主席习近平近日在广西考察时强调，要坚决贯彻党中央决策部署，完整、准确、全面贯彻新发展理念，坚持稳中求进工作总基调，解放思想、深化改革、凝心聚力、担当实干...</h2>  <h3>来源：中国教育新闻网—中国教育报&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li> <li><h1><a href="http://www.jyb.cn/rmtzgjyb/202104/t20210428_551190.html" target="_blank">全国教育经费总投入超5.3万亿元</a></h1> <h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;教育部今天在官网上发布了2020年全国教育经费执行情况统计快报。经初步统计，2020年全国教育经费总投入为53014亿元，比上年增长5.65%。
# 其中，国家财政性教育经费为4...</h2>  <h3> 作者：记者 欧媚&nbsp;&nbsp;&nbsp;&nbsp;来源：中国教育新闻网—中国教育报&nbsp;&nbsp;&nbsp;&nbsp;发布时间：2021-04-28</h3> </li></ul>
